package com.meet.paperface.model;
public class View_Pager_Model {
    
    private int image;

    public View_Pager_Model(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
